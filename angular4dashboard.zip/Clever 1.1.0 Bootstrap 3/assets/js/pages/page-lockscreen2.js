$.backstretch([
  	"assets/img/lockscreen/1b.jpg",
    "assets/img/lockscreen/2b.jpg",
	"assets/img/lockscreen/3b.jpg"
], {
    fade: 1000,
    duration: 4000
});