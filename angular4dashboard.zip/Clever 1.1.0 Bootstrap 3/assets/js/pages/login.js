$(document).ready(function(){
	/* ---------- Placeholder Fix for IE ---------- */
	$('input').iCheck({
		checkboxClass: 'icheckbox_square-blue'
	});
});