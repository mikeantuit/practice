/**
 * Created by yufeimme on 2/15/2017
 */
 'use strict';
 var d3 = require('d3');
 var $ = require('jquery');
 var_ = require('lodash');
 var Highcharts = require('highcharts/highstock');
 window.d3 = d3;
 var customChordLayout = function() {
	 var Ɛ = 1e-6, Ɛ2 = Ɛ * Ɛ, π = Math.PI, τ = 2 * π, τƐ = τ - Ɛ, halfπ = π / 2, d3_radians = π / 180, d3_degrees = 180 / π;
	 var chord = {}, chords, groups, matrix, n, padding = 0, sortGroups, sortSubgroups, sortChords;
	 function relayout() {
		 var subgroups = {}, groupSums = [], groupIndex = d3.range(n), subgroupIndex = [], k, x, x0, i, j;
		 var numSeq;
		 chords = [];
		 groups = [];
		 k=0, i = -1;
		 
         while (++i < n) {
			 x = 0, j = -1, numSeq = [];
			 while (++j < n)  {
				 x += matrix[i][j];
			 }
			 groupSums.push(x);
			 ////////////////////////////////////////////
			 ////////////// New part ////////////////////
			 ////////////////////////////////////////////
			 for(var m = 0; m < n; m++) {
				 numSeq[m] = (n+(i-1)-m)%n;
		     }
			 subgroupIndex.push(numSeq);
			 ////////////////////////////////////////////
			 ////////////// End new part ////////////////
			 ////////////////////////////////////////////
			 k += x;
		 }//while
		 
		 k = (τ - padding * n) / k;
		 x = 0, i = -1;
		 while (++i < n) {
			 x0 = x, j=-1;
			 while (++j < n) {
				 var di = groupIndex[i], dj = subgroupIndex[di][j], v = matrix[di][dj], a0 = x, a1 = x += v * k;
				 subgroups[di + "-" + dj] = {
					 index: di,
					 subindex: dj,
					 startAngle: a0,
					 endAngle: a1,
					 value: v
				 };
			 }//while
			 
			 groups[di] = {
				 index: di,
				 startAngle: x0,
				 endAngle: x,
				 value: (x - x0) / k
			 };
			 x += padding;
		 }//while
		 
		 i = -1;
		 while (++i < n) {
			 j = i - 1;
			 while (++j < n) {
				 var source = subgroups[i + "-" + j], target = subgroups[j + "-" + i];
				 if (source.value || target.value) { 
				     chords.push(source.value < target.value ? {
					     source: target,
						 target: source
				     } : {
						 source: source,
						 target: target
				     });
				 }//if
			 }//while
		 }//while
		 if (sortChords) resort();
	 }//function relayout
	 
	 function resort() {
		 chords.sort(function(a, b) {
			 return sortChords((a.source.value + a.target.value) / 2, (b.source.value + b.target.value) / 2);
		 });
	 }
	 chord.matrix = function(x) {
		 if (!arguments.length) return matrix;
		 n =(matrix = x) && matrix.length;
		 chords = groups = null;
		 return chord;
	 };
	 chord.padding = function(x) {
		 if (!arguments.length) return padding;
		 padding = x; 
		 chords = groups = null;
		 return chord;
	 };
	 chord.sortGroups = function(x) {
		 if (!arguments.length) return sortGroups;
		 sortGroups = x;
		 chords = groups = null;
		 return chord;
	 };
	 chord.sortSubgroups = function(x) {
		 if (!arguments.length) return sortSubgroups;
		 sortSubgroups = x;
		 chords = null;
		 return chord;
	 };
	 chords.sortChords = function(x) {
		 if (!arguments.length) return sortChords;
		 sortChords = x;
		 if (chords) resort();
		 return chord;
	 };
	 chord.chords = function() {
		 if (!chords) relayout();
		 return chord;
     };
	 chord.groups = function() {
		 if (!groups) relayout();
		 return groups;
	 };
	 return chord;
 };
module.exports = ['$rootScope','$stateParams','$scope','$state','cfpLoadingBar'){
	var vm=this;
	vm.grouping=[];
	vm.grouping1=[];
	vm.grouping2=[];
	vm.declinedShow=true;
	vm.walkawayShow=false;
	vm.declinedWeeklyShow=false;
	vm.walkawayWeeklyShow=false;
	vm.watchActivated = false;
	// set the chart width and height 
	var margin = {left:20, top:20, right:20, bottom:20},
	    width = parseInt(d3.select('#chordChart').styke('width'),10)- margin.left - margin.right,
		width1= parseInt(d3.select('#q').style('width'),10) - margin.left - margin.right,
		height=width,
		innerRadius = Math.min(width, height) * .39,
		outerRadius = innerRadius * 1.1;
	var date=[],date1=[new Date('02/09/2016,),new Date('03/24/2017')];
	//store the date and node info to sessionstorage as cache
	if(sessionStorage.date){
		date=JSON.parse(sessionStorage.getItem('date'));
		date.forEach(function(d,i,a){
			a[i]=new Date(Date.parse(d));
		})
	}else{
		date=date1;
	}
	//initialize the datePicker
	vm.datePicker={startDate:sate[0],endDate:date[1]};
	vm.options={
		locale:{
			format:,MM/DD/YYYY',
			customRangeLabel:'Custom range'
		},
		ranges:{
			"Today":date
		}
	};
	vm.show=function(id){
		if(id=='1'){
			vm.declinedShow=false;
			vm.walkawayShow=true;
			vm.declinedWeeklyShow=false;
			vm.walkawayWeeklyShow=false;
		}else if(id=='2'){
			vm.declinedShow=false;
			vm.walkawayShow=false;
			vm.declinedWeeklyShow=true;
			vm.walkawayWeeklyShow=false;
		}else if(id=='3'){
			vm.declinedShow=true;
			vm.walkawayShow=false;
			vm.declinedWeeklyShow=false;
			vm.walkawayWeeklyShow=false;
		}else if(id=='4'){
			vm.declinedShow=false;
			vm.walkawayShow=false;
			vm.declinedWeeklyShow=false;
			vm.walkawayWeeklyShow=true;
		}else if(id=='5'){
			vm.declinedShow=false;
			vm.walkawayShow=false;
			vm.declinedWeeklyShow=false;
			vm.walkawayWeeklyShow=true;
        }else if(id=='6'){
			vm.declinedShow=true;
			vm.walkawayShow=false;
			vm.declinedWeeklyShow=false;
			vm.walkawayWeeklyShow=false;			
		}else if(id=='7'){
			vm.declinedShow=true;
			vm.walkawayShow=false;
			vm.declinedWeeklyShow=true;
			vm.walkawayWeeklyShow=false;
		}else if(id=='8'){
			vm.declinedShow=false;
			vm.walkawayShow=true;
			vm.declinedWeeklyShow=false;
			vm.walkawayWeeklyShow=false;
		}
    }
    if (!$scope.$$phase) {
        $scope.$apply();
    }
    //load data for cross channel chart
    d3.csv('./app/mosaicattribute/crossChanAllPaths.csv',function(error,originData) {
        // vm.matrixData = originData;
        var Names = ['DM',
                'psb',
                'Aggregator',
			    'Brand',
				'psg',
				'Display',
				'psy',
				'Social',
				'SEO',
				'wbm',
				'Email',
				'other_site']
			,
			color = ["#301E1E", "#083E77", "#342350", "#567235", "#8B161C", "#DF7C00", "#ff4000", "#80ff00", "#00ffbf", "#00bfff", "ff00ff", "0040ff"],
			opacityDefault = 0.8;
		var colors = d3.scale.ordinal()
		    .domain(d3.range(Names.length))
			.range(color);
		// var svg = d3.select("#chordChart").append("svg")
		// .attr("width",width + margin.left + margin.right)
		// .attr("height", height + margin.top + margin.bottom)
		// .append("g")
		// .aatr("transform","translate("+(width/2 + margin.left) + "," + (height/2 + margin.top) + ")");
		var date=[new Date('2017-01-12'),new Date('2017-01-25')]
		var dataCopy = angular.copy(originData);
		var matrix=getMatrixDataByData(dataCopy,date)
		drawChord(matrix)
		/**
		 * calculate the chord data of date range user selects
		 * @param json result fom rest call
		 * @param date date user selects
		 * @returns {*}
		 */
		 function getMatrixDataByData(json,date){
			 var data=_.filter(json,function(o) {
				 return new Date(o.date)>=date[0]&&newDate(o.date)<=date[1]
		     })
			 var matrix=[]
			 data.forEach(function(d){
				 matrix.push(JSON.parse(d['Mat']))
			 })
			 var sum=data.reduce(function(a,i){
				 return a+(+i.sum);
			 })
			 var result=matrix.reduce(function(a,i){
				 return assMatrix(a,i,sum)
			 })
			 return result;
		 }
		 // reduce callback function for getMatrixDataByData function
		 function addMatrix(a,b,sum){
			 var result=[]
			 if(a.length!==b.length){
				 return
			 }else{
				 for(var i=0;i<a.length;i++){
					 var temp=[]
					 for(var j=0;j<a[i].length;j++){
						 temp.push(a[i][j]+b[i][j]);
						 //temp.push(a[i][j]+b[i][j])/sum);
					 }
					 result.push(temp)
				 }
				 return result;
			 }
		 }
		 //watch the cange of the date select and update all charts
		 $scope.$watch(function(){return vm.datePicker},function(newVal,oldVal){
			 if(newVal !== oldVal)
			 (
		         var date=[];
				 if(newVal['startDate'] instanceof Date||newVal['endDate'] instanceof Date){
					    date.push(newVal['startDate']);
						date.push(newVal['endDate']);
				 }else{
					 date.push(newVal['startDate'].toDate());
					 date.push(newVal['endDate'].toDate());
				 }
				 var dataCopy = angular.copy(originData);
				 var data = getMatrixDataByData(dataCopy,date);
				 var parent = document.getElementById("chordChart");
				 var child = document.getElementById("chordsvg");
				 parent.removeChild(child);
				 drawChord(data)
				 
		     }
         });
         //main function to draw the chord chart
         function drawChord(data){
             var svg = d3.select("#chordChart").append("svg")
                 .attr("id","chordsvg")
			     .attr("width",width + margin.left + margin.right)
				 .attr("height", height + margin.top + margin.bottom)
				 .append("g")
				 .attr("transform", "translate(" + (width/2 + margin.left) + "," + (height/2 + margin.top) + ")");
				 
//A "custom" d3 chord function that automatically sorts the orders of the chords in such a manner to reduce overlap
             var chord = customChordLayout()
			     .padding(.15)
				 .sortChords(d3.descending)  // which chord should be shown on top when chords cross. Now the biggest chord is at the bottom
				 .matrix(data);
				 
			 var chordarc = d3.svg.arc()
			     .innerRadius(innerRadius*1.01)
				 .outerRadius(outerRadius);
				 
			 var path = d3.svg.chord()
			     .radius(innerRadius);
				
////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// Create the gradient fills /////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
//Function to create the id for each chord gradient
			 function getGradID(d) { return "linkGrad-" + d.source.index + "-" + d.target.index;}

//Create the gradients definitions for each chord
             var grads = svg.append("defs").selectAll("linearGradient")
                 .data (chord.chords())
			 // grads.attr("id", getGradID)
             // .attr("x1", function(d,i) {return innerRadius * Math.cos((d.source.endAngle-d.source.startAngle)/2 + d.source.startAngle - Math.PI/2; })
		     // .attr("y1", function(d,i) {return innerRadius * Math.sin((d.source.endAngle-d.source.startAngle)/2 + d.source.startAngle - Math.PI/2; })
			 // .attr("x2", function(d,i) {return innerRadius * Math.cos((d.target.endAngle-d.target.startAngle)/2 + d.target.startAngle - Math.PI/2);})
			 // .attr("y2", function(d,i) {return innerRadius * Math.sin((d.target.endAngle-d.target.startAngle)/2 + d.target.startAngle - Math.PI/2);})
			 // grads.select(".stop1").attr("offset","0%")
			 // .attr("stop-color", function(d) { return colors(d.source.index); });
			 // grads.select(".stop2").attr("offset","100%")
			 // .attr("stop-color", function(d) { return colors(d.target.index);});
			 
			 grads.enter().append("linearGradient:)
			      .attr("id", getGradID)
				  .attr("gradientUnits", "userSpaceOnUse")
				  .attr("x1",function(d,i) { return innerRadius * Math.cos((d.source.endAngle-d.source.startAngle)/2 + d.source.startAngle - Math.PI/2); })
				  .attr("y1",function(d,i) { return innerRadius * Math.sin((d.source.endAngle-d.source.startAngle)/2 + d.source.startAngle - Math.PI/2); })
				  .attr("x2",function(d,i) { return innerRadius * Math.cos((d.target.endAngle-d.target.startAngle)/2 + d.target.startAngle - Math.PI/2); })
				  .attr("y2",function(d,i) { return innerRadius * Math.sin((d.target.endAngle-d.target.startAngle)/2 + d.target.startAngle - Math.PI/2); })
				  .append("stop")
				  .attr("class","stop1")
				  .attr("offset","0%")
				  .attr("stop=color", function(d) { return colors(d.source.index);})
				  .select(function(){return this.parentNode;})
				  .append("stop")
				  .attr("class","stop2")
				  .attr("offset","100%")
				  .attr("stop=color", function(d) { return colors(d.target.index); });
				// grads.exit().remove();
///////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// Draw Outer Arcs //////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

              var outerArcs = svg.selectAll("g.group")
			  .data(chord.groups)
              // outerArcs.selectAll("path")
			  //  .style("fill", function(d) { return colors(d.index); })
			  //  .attr("d", chordarc)
			  //  .each(function(d,i) {
			  //   // Search pattern for everything between the start and the capital L
			  //   var firstArcSection = /(^.+?)L/;
			  //
			  //   //Grab everything up to the first Line statement
			  // var newArc= firstArcSection.exec(d3.select(this).attr("d"))[1];
			  //   // Replace all the comma's so that IE can handle it
			  //   newArc = newArc.replace(/,/g," ");
			  //
			  //   //If the end angle lies beyond a quarter of a circle (90 degrees or pi/2)
			  //   //flip the end and start position
			  //   if (d.endangle > 90*Math.PI/180 & d.startAngle < 270*Math.PI/180) {
			  //	var startLoc = /M(.*?)A /,  //Everything between the first capital M and first capital A
			  //    middleLoc = /A(.*?)0 01/, //Everything betweem the first capital A and 0 0 1 
			  //    endLoc = /0 0 1(.*?)$/; ??Everything between the first 0 0 1 and the end of the string (denoted by $)
			  //    //Flip the direction of the arc by switching the start en end point(and sweep flag)
			  //    //of those elements that are below the horizontal line
			  //    var newStart = endLoc.exec(newArc)[1];
			  //    var newEnd = startLoc.exec(newArc)[1];
			  //    var middleSec = middleLoc.exec(newArc)[i];
			  //
			  //    //Build up the new arc notation, set the sweep-flag to 0
			  //    newArc = "M" + newStart + "A" + middleSec + "0 0 0 " + newEnd;
			  //    }//if
			  //    //Create a new invisible arc that the text can flow along
			  //    //svg.append("path")
			  //    // .attr("class","hiddenArcs")
			  //    // .attr("id","arc"+i)
			  //    // .attr("d",newArc)
			  //    // .style("fill","none");
			  //    });
			  //  outerArcs.selectAll("text")
			  //  .attr("dy", function(d,i) { return (d.endAngle > 90*Math.PI/180 & d.startAngle < 270*Math.PI/ 180 ? 25 : -16); })
			  // outerArcs.selectAll("textPath")
			  // .attr("xlink:href",function(d,i){return "#arc"+i;})
			  // .text \(function(d,i){ return Names[i];});
			  var outerArcsEnter=outerArcs.enter().append("g")
				  .attr("class","group")
				  .on("mouseover", fade(.1))
				  .on("mouseout", fade(opacityDefault));
			  outerArcsEnter.append("path")
			       .style("fill",function(d) { return colors(d.index); })
				   .attr("d", chordarc)
				   .each(function(d,i) {
					   //Search pattern for everything between the start and the first capital L
					   var firstArcSection = /(^.+?)L/;
					   
					   //Grab everything up to the first Line Statement
					   var newArc = firstArcSection.exec( d3.select(this).attr("d"))[1];
					   //Replace all the comma's so that IE can handle it
					   newArc = newArc.replace(/,/g, " ");
					   
					   //If the end angle lies beyound a quarter of a circle (90 degrees or pi/2)
					   //flip the end and start position 
					   if (d.endAngle > 90*Math.PI/180 & d.start.Angle < 270*Math.PI/180) { 
					       var startLoc  = /M(.*?)A/, //Everything between the first capital M and first capital A
						       middleLoc = /A(.*?) 0 0 1/, //Everything between the first capital A and 0 0 1
							   endLoc    = /0 0 1 (.*?)$/; //Everything between the first 0 0 1 and the end of the string (denoted by $)
							                               //Flip the direction of the arc by switching the start en end point (and sweep flag)
														   //of those elements that are below the horizontal line
														   var newStart = endLoc.exec(newArc )[1];
														   var newEnd = startLoc.exec(newArc )[1];
														   var middleSec = middleLoc.exec(newArc )[1];
														   
														   //Build up the the new arc notation, set the sweep-flag to 0
														   newArc = "M" + newStart + "A" + middleSec + "0 0 0 " + newEnd;
					   }//if
					   
					    //Create a new invisible arc that the text can flow along
						svg.append("path")
						.attr("class", "hiddenArcs")
						.attr("id", "arc"+i)
						.attr("d", newArc)
						.style("fill", "none");
				   });
				   
				   /////////////////////////////////////////////////////////////////////////////////////////
				   /////////////////////////Append Names////////////////////////////////////////////////////
				   /////////////////////////////////////////////////////////////////////////////////////////
				   
				   //Append the label names on the outside 
				              outsideArcsEnter.append("text")
									.attr("class","titles")
									.attr("dy",function(d,i) { return (d.endangle > 90*Math.PI/180 & d.startAngle < 270*Math.PI/180 ? 25 : -16); })
									.append("textPath")
									.attr("startOffset","50%:)
									.style("text-anchor","middle")
									.attr("xlink:href",function(d,i){return "#arc"+i;})
									.text(function(d,i){ return Names[i]; });
								outerArcs.exit().remove();
								///////////////////////////////////////////////////////////////////////////////
								/////////////////////// Draw inner chords /////////////////////////////////////
								///////////////////////////////////////////////////////////////////////////////
								
								var chordGroup=svg.selectAll("path.chord")
								    .data(chord.chords)
								// chordGroup.style("fill", function(d){ return "url(#" + getGradID(d) + ")"; })
								// .attr("d",path)
								chordGroup.enter().append("path")
								    .attr("class", "chord")
									.style("fill", function(d) { return "url(#" + getGradId(d) + ")"; })
									.style("opacity", opacityDefault)
									.attr("d", path)
									.on("mouseover", mouseoverChord)
									.on("mouseout", mouseoutChord);
								// chordGroup.exit().remove();
								///////////////////////////////////////////////////////////////////////////////////
								////////////// Extra Function /////////////////////////////////////////////////////
								///////////////////////////////////////////////////////////////////////////////////
								
								//Returns an event handler for fading a given chord group 
									function fade(opacity) {
										return function(d,i) {
											svg.selectAll("path.chord")
												.filter(function(d) { return d.source.index !== i && d.target.index !== i; })
												.transition()
												.style("opacity", opacity);
										};
									}//fade

//Highlight hovered over chord 
                                    function mouseoverChord(d,i) {

                                        //Decrease opacity to all
                                        svg.selectAll("path.chord")
										   .transition()
										   .style("opacity", 0.1);
										//Show hovered over chord with full opacity
										d3.select(this)
											.transition()
											.style("opacity", 1);
											 
										//Define and show the tooltip over the mouse3 location
										$(this).popover({
											placement: 'auto top',
											container: 'body',
											mouseOffset: 10,
											followMouse: true,
											trigger: 'hover',
											html : true,
											content: function() {
												return "<p style="font-size: 11px; text-align: center;'><span style=' font-weight:900'>" + Names[d.source.index] +
												   "</span> and <span style=' font-weight:900'>" + Names[d.target.index] +
											"</span> appeared together in <span style='font-weight:900'>" + d.source.value + "</span> channel </p>"; }
										});
										$(this).popover('show');
									}//mouseoverChord
									
							//Bring all chords back to default opacity
									function mouseoutChord(d)  {
										//Hide the tooltip
										$('.popover').each(function() {
											$(this).remove();
									}};
									//Set opacity back to default for all
									svg.selectAll("path.chord")
										.transition()
										.style("opacity", opacityDefault);
		                             }
                                }
                     }}
									
	                 //This is for Table BreadCrumbs Automatic Looping with Data fileCreatedDate
					 // cfpLoadingBar.start();
					 //Load data for converted path
					 d3.json('./app/mosaicattribute/convertedStatesPaths_Apr5.json',function(error,json) {
						 var sumCount;
						 //format the date and value into date object and number
						 var formattedData=json.map(function(d) {
							 d.date=new Date(d.date);
							 return d;
					     }};
						 //sort the data by descend orders
						 formattedData.sort(function(a,b) {
							 return b.date-a.date;
						 }};
						 var dataCopy = angular.copy(formattedData);
						 var data=pathDataByDate(dateCopy,date);
						 drawPath(data);
						 vm.pathLine=function(pathData) {
							 var res=[] , date=[]
							 pathData.forEach(function(d){
								 res.push(d.name)
							 })
							 var pathString=res.join('-'_;
							 date[0]=vm.datePicker.start||vm.datePicker.startDate._d;
							 date[1]=vm.datePicker.endDate||vm.datePicker.endDate._d;
							 var dataCopy = angular.copy(formattedData);
							 dataCopy=_.filter(dataCopy,function(d){
								 return d.date<=date[1]&&d.date[0];
							 })
							 var data =nestArray(dataCopy);
							 var result=_.filter(data,function(d){
								 return_.isEqual(d.path,res)
							 })
							 var chartData=[]
							 for(var i=result.length-1;i>=0;i--) {
								 chartData.push([result[i].date.getTime(),result[i].count])
							 }
							 $("#myModal").modal("show");
							 vm.pathLineChart=Highcharts.StockChart('pathLinechart',{
								 credits: {
									 enabled: false
								 },
								 title:{
									 text:pathString
							 },
							 series:[{
								 name"pathString,
								 data"ChartData,
								 type:"splime"
							 }]
						 })
					}
					//watch the change of the date select and update all charts
					$scope.$watch(function(){return vm.datePicker},function(newVal,oldVal) {
						if(newVal !== oldVal)
						{
							var date=[];
							if(newVal['startDate'] instanceof Date||newVal['endDate'] instanceof Date) {
								date.push(newVal['startDate']);
								date.push(newVal['endDate']);
							}else {
								date.push(newVal['startDate'].toDate() );
								date.push(newVal['endDate'].toDate() );
							}
							var dataCopy = angular.copy(formattedData);
							var data=pathDataByDate(dataCopy,date);
							drawPath(data);
						}
					}}
					/**
					 * get data for converted path
					 * @param data result from rest call 
					 * @param date date user selects
					 * @returns {*}
					 */
					 function pathDataByDate(data,date) {
						 var newData;
						 date[0].setHours(0,0,0,0)
						 date[1].setHours(0,0,0,0)
						 newData=data.filter(function(d) {
							 return d.date>=date[0]&&d.date<=date[1]
						 })
						 sumCount=newData.reduce(function(a,b) {
							 return {count:a.count+b.count};
						 })
						 vm.totalConversions = sumCount;
						 var channelArray=nestArray(newData)
						 for(var i=0; i<channelArray.length; i++) {
							 for(var j=i+1;j<channelArray.length;j++) {
								 if(_.isEqual(channelArray[i]['path'],channelArray[j]['path'])) {
									 channelArray[i]['count']=channelArray[i]['count']+channelArray[j]['count']
									 channelArray.splice(j,1)
									 j--
								 }
							 }
						 }
						 return channelArray
					 }
					 //draw the converted path, sort formatted data into $scope arrat
					 function drawPath(data) {
						 vm.grouping = [];
						 angular.forEach(data,function(value,key){
							 var res=[];
							 value['path'].forEach(function(d) {
								 if(d=='DM'||d=='DirectMail'){
									 res.push({'name':d,'color':'#3498db'})
								 }else if(d=='dmp'||d=='Paid Search'){
									 res.push({'name':d,'color':'#44a5e5'})
								 }else if(d=='ag1'||d=='DispAcq'){
									 res.push({'name':d,'color':'palevioletred'})
								 }else if(d=='other_site'||d=='othersite'){
									 res.push({'name':d,'color':'#96ceb4'})
								 }else if(d=='psg_Brand'||d=='Paid Search Brand'){
									 res.push({'name':d,'color':'#d9ad7c'})
								 }else if(d=='SEO'||d=='Email'){
									 res.push({'name':d,'color':'#f18973'})
								 }else if(d=='PS_uknownCID'||d=='Disp Brand'){
									 res.push({'name':d,'color':'#ff6f69'})
								 }else if(d=='agk'||d=='Aggregator_API'){
									 res.push({'name':d,'color':'#2ecc71'})
								 }else if(d=='Display'){
									 res.push({'name':d,'color':'#eeac99'})
								 }else if(d=='Social'){
									 res.push({'name':d,'color':'#e06377'})
								 }else if(d=='wbm'){
									 res.push({'name':d,'color':'#c83349'})
								 }
								 else{
									 res.push({'name':d,'color':'steelblue'})
								 }
							 });
							 vm.grouping.push({"data":res,"percentage":value['count']/sumCount.count*100});
							 if (!$scope.$$phase) {
								 $scope.$apply();
							 }
						 })
					 }
					 })
					 //load data for nonConverted path
					 d3.json('./app/mosaicattribute/declinedStatesPaths_Apr5.json',function(error,json){
						 var sumCount;
						 //format the Date and Value into date object and number
						 var formattedData=json.map(function(d){
							 d.date=new Date(d.date);
							 return d;
						 });
						 //sort the data by descend order
						 formattedData.sort(function(a,b){
							 return b.date-a.date;
						 });
						 var dataCopy = angular.copy(formattedData);
						 var data=pathDataByDate(dataCopy,date);
						 drawPath(data)
						 vm.pathLineNon=function(pathData) {
							 var res=[],date=[]
							 pathData.forEach(function(d) {
								 res.push(d.name)
							 })
							 var pathString=res.join('-');
							 date[0]=vm.datePicker.startDate||vm.datePicker.startDate._d;
							 date[1]=vm.datePicker.endDate||vm.datePicker.endDate._d;
							 var dataCopy = angular.copy(formattedData);
							 dataCopy=_.filter(dataCopy,function(d){
								 return d.date<=date[1]&&d.date>=date[0];
							 })
							 var data=nestArray(dataCopy);
							 var result=_.filter(data,function(d){
								 return _.isEqual(d.path,res)
							 })
							 var chartData=[]
							 for(var i=result.length-1;i>=0;i--) {
							 chartData.push([result[i].date.getTime(),result[i].count])
							 }
							 $("#myModal").modal("show");
							 vm.pathLineChart=Highcharts.StockChart('pathlinechart',{
								 credits: {
									 enabled: false
								 },
								 title:{
								 text:pathString
								 },
								 series:[{
									 name"pathString,
									 data:chartData,
									 type:"spline"
								 }]
							 })
						 }
						 //watch the change of the date select and update all charts
						 $scope.$watch(function() {return vm.datePicker},function(newVal,oldVal){
							 
							 if(newVal !== oldVal)
							 {
								 var date=[];
								 if(newVal['startDate'] instanceof Date||newVal['endDate'] instanceof Date) {
									 date.push(newVal['startDate']);
									 date.push(newVal['endDate']);
								 }else{
									 date.push(newVal['startDate'].toDate());
									 date.push(newVal['endDate'].toDate());
								 }
								 var dataCopy = angular.copy(formattedData);
								 var data-pathDataByDate(dataCopy,date);
								 drawPath(data);
							 }
						 });
						 /**
						 *get data for nonConverted path
						 * @param data result from rest call
						 * @param date date user selects
						 * @returns {*}
						 */
						 function pathDataByDate(data,date) {
							 var newData
							 date[0].setHours(0,0,0,0)
							 date[1].setHours(0,0,0,0)
							 newData=data.filter(function(d){
								 return d.date>=date[0]&&.date<=date[1]
						 })
						 sumCount=newData.reduce(function(a,b) { 
							return {count:a.count+b.count};
						 })
						 vm.totalConversionsl = sumCount;
						 var channelArray=nestArray(newData)
						 for(var i=0;i<channelArray.length;i++){
							 for(var j=i+1;j<channelArray.length;j++) {
								 if(_.isEqual( ChannelArray[i]['path'],channelArray[j]['path'])){
									 channelArray[i]['count']=channelArray[i]['count']+channelArray[j]['count']
									 channelArray.splice(j,1)
								 j--
								 }
							 }
						 }
						 return channelArray
					}
					//draw the converted path,sort formatted data into $scope array
					function drawPath(data) {
						vm.grouping1 = [];
						angular.forEach(data,function(value,key) {
							var res=[];
							value['path'].forEach(function(d){
								if(d=='DM'||d=='DirectMail'){
								res.push({'name':d,'color':'#3498db'})
								}else if(d=='dmp'||d=='Paid Search'){
									res.push({'name':d,'color':'#44a5e5'})
								}else if(d=='ag1'||d=='Disp Acq'){
								    res.push({'name':d,'color':'palevioletred'})
								}else if(d=='other_site'||d=='othersite){
								    res.push({'name':d,'color':'#96ceb4'})
								}else if(d=='psg_Brand'||d=='Paid Search Brand'){
								    res.push({'name':d,'color':'#d9ad7c'})
								}else if(d=='SEO'||d=='Email'){
								    res.push({'name':d,'color':'#f18973'})
								}else if(d=='PS_uknownCID'||d=='Disp Brand'){
								    res.push({'name':d,'color':'#ff6f69'})
								}else if(d=='agk'||d=='Aggregator_AP1'){
								    res.push({'name':d,'color':'#2ecc71'})
								}else if(d=='Display'){
								    res.push({'name':d,'color':'#eeac99'})
								}else if(d=='Social'){
								    res.push({'name':d,'color':'#e06377'})
								}else if(d=='wbm'){
								    res.push({'name':d,'color':'#c83349'})
								}
								else{
									res.push({'name':d,'color':'steelblue'})
								}
							})
							vm.grouping1.push({"data":res,"percentage":((value.count)/sumCount.count)*100});
							if (!$scope.$$phase){
								$scope.$apply();
							}
					    })
					}
				})
				//load data for nonConverted path of weekly comparison
				d3.json('./app/mosaicattribute/declinedStatesPaths_Apr5.json',function(error,json){
					//format the date and value into date object and number
					var formattedData=json.map(function(d) {
						d.date=new Date(d.date);
						return d;
					});
					//sort the data by descend order
					formattedData.sort(function(a,b) {
						return b.date-a.date;
					});
					var today=formattedData[0]['date'];
					var priorDate1 = new Date(today.getTime() - 7*24*60*60*1000)
					var priorDate2 = new Date(today.getTime() - 14*24*60*60*1000)
					var priorDate3 = new Date(today.getTime() - 21*24*60*60*1000)
					var priorDate4 = new Date(today.getTime() - 28*24*60*60*1000)
					var dataCopy = angular.copy(formattedData);
					var data1=pathDataByDate(dataCopy,[priorDate1,today])
					var data2=pathDataByDate(dataCopy,[priorDate2,priorDate1])
					var data3=pathDataByDate(dataCopy,[priorDate3,priorDate2])
					var data4=pathDataByDate(dataCopy,[priorDate4,priorDate3])
					var week12=findSamePath(data1,data2)
					var week23=findSamePath(data2,data3)
					var week34=findSamePath(data3,data4)
					vm.week1=drawPath(week12[0],[])
					vm.week2=drawPath(week12[1],[])
					vm.week3=drawPath(week23[0],[])
					vm.week4=drawPath(week23[1],[])
					vm.week5=drawPath(week34[0],[])
					vm.week6=drawPath(week34[1],[])
                    vm.today=today
					vm.priorDate1=priorDate1
					vm.priorDate2=priorDate2
					vm.priorDate3=priorDate3
					vm.priorDate4=priorDate4
					if (!$scope.$$phase) {
						$scope.$apply();
					}
					//find the same path between two weeks
					function findSamePath(a,b) {
						a.sort(function(a,b){
							return b.count=a.count
						})
						var temp1=[],temp2=[]
						for(var i=0;i<a.length;i++) {
							for(var j=0;j<b.length;j++) {
								if(_.isEqual(a[i].path,b[j].path)){
									temp1.push(a[i])
									temp2.push(b[j])
								}
							}
						}
						return [temp1,temp2]
					}
					/**
					 * get data for nonConverted path* @param data result from rest Call
					 * @param data result from rest call 
					 *@param date date user selects
					 * @returns {*}
					 */
					function pathDataByDate(data,date) {
						var newData,SUMcOUNT
						newData=data.filter(function(d) {
							Return d.date>=date[0]&&d.date<=date[1]
						})
						sumCount=newData.reduce(function(a,b) {
							return {count:a.count+b.count};
						})
						var channelArray=nestArray(newData)
						for(var i=0;i<channelArray.length;i++){
							for(var j=i+1;j<channelArray.length;j++) {
								if(_.isEqual(channelArray[i]['path'],channelArray[j]['path'])){
									channelArray[i]['count']=channelArray[i]['count']+channelArray[j]['count']
									channelArray.splice(j,1)
									j--
								}
							}
							channelArray[i]['count']=channelArray[i]['count']/sumCount["count"]*100
						}
					return channelArray
					}
					//draw the converted path, sort formatted data into $scope array
					function drawPath(data,array){
						array=array||[]
						angular.forEach(data,function(value,key){
							var res=[];
							value['path'].forEach(function(d){
								if(d=='DM' || d=='DirectMail') {
									res.push({'name':d,'color':'#3498db'})
								}else if(d=='dmp' || d=='Paid Search'){
									res.push({'name':d,'color':'#44a5e5'})
								}else if(d=='ag1'||d=='Disp Acq'){
									res.push({'name':d,'color':'palevioletred'})
								}else if(d=='other_site'||d=='othersite'){
									res.push({'name':d,'color':'#96ceb4'})
								}else if(d=='psg_Brand'||d=='Paid Search Brand'){
								    res.push({'name':d,'color':'#d9ad7c'})
								}else if(d=='SEO'||d=='Email'){
								    res.push({'name':d,'color':'#f18973'})
								}else if(d=='PS_uknownCID'||d=='Disp Brand'){
								    res.push({'name':d,'color':'#ff6f69'})
								}else if(d=='agk'||d=='Aggregator_AP1'){
								    res.push({'name':d,'color':'#2ecc71'})
								}else if(d=='Display'){
								    res.push({'name':d,'color':'#eeac99'})
								}else if(d=='Social'){
								    res.push({'name':d,'color':'#e06377'})
								}else if(d=='wbm'){
								    res.push({'name':d,'color':'#c83349'})
								}
								else{
									res.push({'name':d,'color':'steelblue'})
								}
							})
							array.push({"data":res,"percentage":value.count});
						})
						return array;
					}
					cfpLoadingBar.complete()
				})
				
				//load data for nonConverted path
				d3.json('./app/mosaicattribute/walkawayStatesPaths_Apr5.json',function(error,json){
					var sumCount;
					//format the date and value into date object and number
					var formattedData=json.map(function(d){
						d.date=new Date(d.date);
						return d;
					});
					//sort the data by descend order
					formattedData.sort(function(a,b) {
						return b.date-a.date;
					});
					var dataCopy = angular.copy(formattedData);
					var data=pathDatByDate(dataCopy,date);
					drawPath(data)
					vm.pathLineNon=function(pathData) {
						var res= [], date[]
						pathData.forEach(function(d) {
							res.push(d.name)
						})
						var pathString=res.join('-');
						date[0]=vm.datePicker.startDate||vm.datePicker.startDate._d;
						date[1]=vm.datePicker.endDate||vm.datePicker.endDate._d;
						var dataCopy = angular.copy(formattedData);
						dataCopy=_.filter(dataCopy,function(d){
							return d.date<=date[1]&&d.date>=date[0];
						})
						var data=nestArray(dataCopy);
						var result=_.filter(data,function(d){
							return_.isEqual(d.path,res)
						})
						var chartData=[]
						for(var i=result.length-1;i>=0;i--){
							chartData.push([result[i].date.getTime(),result[i].count])
						}
						$("#myModal").modal("show");
						vm.pathLineChart=Highcharts.StockCghart('pathlinechart',{
						credits: {
						enabled: false
						},
						title:{
						text:pathString
						},
						series"[{
							name:pathString,
							data:chartData,
							type:"spline"
						}]
						})
					}
					//watch the change of the date select and update all charts
					$scope/$watch(function() {return vm.datePicker},function(newVal,oldVal){
						
					if(newVal !== oldVal)
					{
						var date=[];
						if(newVal['startDate'] instanceof Date||newVal['endDate'] instanceof Date){
							date.push(newVal['startDate']);
							date.push(newVal;['endDate']);
						}else{
							date.push(newVal['startDate'].toDate());
							date.push(newVal['endDate'].toDate());
						}
						var dataCopy = angular.copy(formattedData);
						var data=pathDataByDate(dataCopy,date);
						drawPath(data);
					}
					});
					/**
					* get data for nonConverted path
					* @path data result from rest call
					* @param date date user selecta
					*@returns (*)
					*/
		function pathDataByDate(data, date) {
			var newData
			date[0].setHours (0,0,0,0)
			date[1].setHours(0,0,0,0)
			newData=data.filter(function (d){
				return d.date>=date[0]&&d.date<=date[1]
			})
			sumcount=newData.reduce(function(a,b){
				return {count:a.count+b.count};
			})
			vm.totalConversions2=sumCount;
			var channelArray=nestArray(newData)
			for(var i=0;i<channelArray.length;j++) {
				for(var j=i+1;j<channelArray.length;j++) {
				if(_.isEqual(channelArray[i]['path'],channelArray[j]['path'])) {
					channelArray[i]['count']=channelArray[i]['count]+channelArray[j]['count]
					channelArray.splice(j,i)
					j--
				}
			}
		}
		return channelArray
	}
	//draw the converted path, sort formatted data into $scope array
		function drawPath(data) {
			vm.grouping2 = []
			angular.forEach(data, function(value, key) {
				var res=[];
				value['path'].forEach(function (d) {
					if(d=='DM' || d=='DirectMail') {
						res.push({'name':d,'color': '3498db'})
					}else if(d=='dmp' || d=='Paid Search') {
					res.push({'name':d,'color':'#445e5'})
					}else if(d=='ag1' || d=='Disp Acq'){
						res.push({'name':d,'color':'palevioletred'})
					}else if (d=='other_site' || d=='othersite'){
						res.push({'name':d,'color':'#96ceb4'})
					}else if(d=='psg_Brand'||d=='Paid Search Brand') {
						res.push({'name':d,'color':'#d9ad7c'})
					}else if(d=='SEO' || d=='Email') {
					res.push({'name':d,'color':'#f18973'})
					}else if(d=='PS_uknownCID' || d=='Disp Brand'){
						res.push({'name':d,'color':'#ff6f69'})
					}else if (d=='agk' || d=='Aggregator_API'){
						res.push({'name':d,'color':'#2ecc71'})
					}else if(d=='Display') {
						res.push({'name':d,'color':'#eeac99'})
					}else if(d=='Social') {
						res.push({'name':d,'color':'#e06377'})
					}else if(d=='wbm') {
						res.push({'name':d,'color':'#eeac99'})
					}
					else{
						res.push({'name':d,'color':'steelblue'})
					}
				})
				vm.grouping2.push({"data":res,"percentage":((value.count)/sumCount.count)*100});
				if (!$scope.$$phase) {
					$scope.$apply();
				}
			})
		}
	})
	//load date for nonConverted path of weekly comparison
	d3.json('./app/mosaicattribute/walkawayStatesPaths_Apr5.json',function(error, json){
		//format the date and value into date object and number
		var formattedData=json.map(function(d){
			d.date=new Date(d.date);
			return d;
		});
		//sort the data by descend order
		formattedData.sort(function(a,b) {
			return b.date-a.date;
		});
		var today=formattedData[0]['date'];
		var priorDate1=new Date(today.getTime() - 7*24*60*60*1000)
		var priorDate2=new Date(today.getTime() - 14*24*60*60*1000)
		var priorDate3=new Date(today.getTime() - 21*24*60*60*1000)
		var priorDate4=new Date(today.getTime() - 28*24*60*60*1000)
		var dataCopy=angular.copy(formattedData);
		var data1=pathDataByDate(dataCopy,[priorDate1,today])
		var data2=pathDataByDate(dataCopy,[priorDate2,priorDate1])
		var data3=pathDataByDate(dataCopy,[priorDate3,priorDate2])
		var data4=pathDataByDate(dataCopy,[priorDate4,priorDate3])
		var week12=findSamePath(data1,data2)
		var week23=findSamePath(data2,data3)
		var week34=findSamePath(data3,data4)
		vm.walkawayweek1=drawPath(week12[0],[])
		vm.walkawayweek2=drawPath(week12[1],[])
		vm.walkawayweek3=drawPath(week23[0],[])
		vm.walkawayweek4=drawPath(week23[1],[])
		vm.walkawayweek5=drawPath(week34[0],[])
		vm.walkawayweek6=drawPath(week34[1],[])
		vm.today=today
		vm.priorDate1=priorDate1
		vm.priorDate2=priorDate2
		vm.priorDate3=priorDate3
		vm.priorDate4=priorDate4
		if (!$scope.$$phase) {
			$scope.apply();
		}
		//find the same path between two weeks
		function findSamePath(a,b){
			a.sort(function(a,b){
				return b.count-a.count
			})
			var temp1=[], temp2=[]
			for(var i=0;i<a.length;i++) {
				for(var j=0;j<b.length;j++) {
					if(_.isEqual(a[i].path,b[j].path)) {
					temp1.push(a[i])
					temp2.push(b[j])
				}
			}
		}
		return [temp1, temp2]
	}
	/**
	*get data for nonConverted path
	*@param data result from rest call
	*@param date date user selects
	*@returns {*}
	*/
	function pathDataByDate(data, date){
		var newData,sumCount
		newData=data.filter(function (d) {
			return d.date>=date[0]&&d.date<=date[1]
		})
		sumCount=newData.reduce(function(a,b){
			return {count:a.count+b.count};
		})
		var channelArray=nestArray(newData)
		for(var i=0;i<channelArray.length;i++) {
			for(var j=i+1;j<channelArray.length;j++) {
				if(_.isEqual(channelArray[i]['path'],channelArray[j]['path'])) {
					channelArray[i]['count'] = channelArray[i]['count']+channelArray[j]['count']
					channelArray.splice(j,1)
					j--
				}
			}
			channelArray[i]['count'=channelArray[i]['count']/sumCount['count']*100
			}
			return channelArray
		}
		//draw the converted path, sort formatted data into $scope array
		function drawPAth(data,array){
			array=array||[]
			angular.forEach(data, function(value,key){
				var res=[]
				value['path'].forEach(function(d) {
					if(d=='DM'||d=='DirectMail') {
						res.push({'name':d,'color':'3498db'})
					} else if(d=='dmp'||d=='Paid Search'){
						res.push({'name':d,'color':'#44a5e5'})
					}else if(d=='agl'||d=='Disq Acq') {
						res.push({'name':d,'color':'palevioletred'})
					}else if(d=='other_site'||d=='othersite') {
						res.push({'name':d,'color':'#96ceb4'})
					}else if(d=='psg_Brand'||d=='Paid Search Brand') {
						res.push({'name':d,'color':'#d9ad7c'})
					}else if(d=='SEO'||d=='Email') {
						res.push({'name':d,'color':'#f18973'})
					}else if(d=='PS_uknownCID'||d=='Disp Brand') {
						res.push({'name':d,'color':'#ff6f69'})
					}else if(d=='agk'||d=='Aggregator_API') {
						res.push({'name':d,'color':'#2ecc71'})
					}else if(d=='Display') {
						res.push({'name':d,'color':'#eeac99'})
					}else if(d=='Social'){
						res.push({'name':d,'color':'#e06377'})
					}else if(d=='wbm') {
						res.push({'name':d,'color':'#c83349'})
					}
					else{
						res.push({'name':d,'color':'steelblue'})
					}
				})
				array.push({"data":res,"percentage":value.count});
			})
			return array;
		}
		cfpLoadingBar.complete()
	})



	//store path in a array for comparison purpose;
	function nestArray(array) {
		var result=array.map(function(d){
			var count=d.count;
			var date=d.date;
			var path=[];
			for(var i=1;i<=Object.keys(d).length-2;i++){
				path.push(d["ch"+i])
			}
			return {'path':path,'count':count,'date':date}
		})
		return result;
	}

	//Breadcrumb starts here
//	var b={w:12,h:35,s:3,t:10};
//	var color=d3.scale.category10();
//	var totalSize=0;
//	var radius=(Math.min(width,height)/2)-10;
//	var x=d3.scale.linear().range([0,2*Math.PT]);
//	var y=d3.scale.sqrt().range([0,radius]);
//	var partition=d3.layout.partition().value(function(d) {return d.size;});
//	var arc=d3.svg.arc()
//	.startAngle(function(d) {return Math.max(0,Math.min(2*Math.PI,x(d.x))) ; })
//	.endAngle(function(d) {return Math.max(0,Math.min(2*Math.PI,x(d.x+d.dx))) ; })
//	.innerRadius(function(d) {return Math.max(0,y(d.y))) ; })
//	.outerRadius(function(d) {return Math.max(0,y(d.y+d.dy))) ; })
//	function updateBreadcrumbs(nodeArray, percentageString,id) {
//	var breadcrumbs=d3.select('#'+id)
//	.selectAll('g')
// .data(nodeArray,function(d) {
// 	if(d.name!==""){
// 		return d.name;
// 	}
// });
// var entering=breadCrumbs.enter()
// .append('g');
// entering.append('polygon')
// .attr('points',function(d,i){
// 	return breadcrumbPoints(nodeArray,i)
// })
// .style('fill',function(d){
// 	if(d.name='Direct Mail') {
// 		return '#3498db';
// 	} else if(d.name='other_imp'){
// 		return '#1abc9c';
// 	} else if(d.name='paid_search'){
// 		return 'df7c00';
// 	}else if(d.name='aggregator'){
// 		return '#red';
// 	}else {
// 		return 'steelblue';
// 	}
// });
// entering.append('text')
// 	.attr('x',function(d,i){
// 		return (b.w*nodeArray[i].name.length+b.t)/2
// 	})
// 	.attr('y',b.h/2)
// 	.attr('text-anchor','middle')
// 	.attr('dy',"0.35em")
// 	.text(function(d,i){
// 		return d.name
// 	});
// breadCrumbs.attr('transform',function(d,i){
// 	var distance = breadcrumbTransformDistance(nodeArray,i)
// 	return "translate("+distance+",0)"
// });
// console.log(breadCrumbs)
// breadCrumbs.exit().remove();
// d3.select('#'+id).select('#endlabel')
// 	.attr('x',function(d){
// 		return breadcrumbTransformDistance(nodeArray,nodeArray.length)+30;
// 	})
// 	.attr('y',b.h/2)
// 	.attr('dy',"0.35em")
// 	.attr('text-anchor','middle')
// 	.attr('font',"15px")
// 	.text(percentageString);
// d3.select('#'+id)
// 	.style('visibility',"")
// if (!$scope.$$phase) {
// 	$scope.$apply();
//     }
// }
// function initializeBreadcrumbTrail(id,trailId,width) {
// 	add the svg area 
// 	d3.select('#'+id).remove();
// 	var trail=d3.select('#'+id).append('svg')
// 	console.log(d3.select('#'+id) [0])
// 	console.log(trail[0])
// 	trail.attr('id',trailId)
// 		  .attr('width',width)
// 		  .attr('height',35)
// 		  .attr('transform',"translate("+=+","+10+")")
// 		  //add the label at the end for the percentage
// 		  .append('text')
// 		  .attr('id','endlabel')
// 		  .style('fill','#000')
// }
// //generate a string that describes the points of a breadcrumb polygon
		// function breadcrumbPoints(text,i){
		// 	var points=[];
		// 	var textLength=text[i].name.length;
		// 	points.push("0,0");
		// 	points.push(b.w*textLength+",0");
		// 	points.push(b.w*textLength+b.t+","+(b.h/2));
		// 	points.push(b.w*textLength+","+b.h);
		// 	points.push("0,"+b.h);
		// 	if(i>0) {
		// 		points.push(b.t+","+(b.h/2))
		// 	}
		// 	return points.join(" ")
		// }
		// //calculate breadcrumb transform distance
		// function breadcrumbTransformDistance(text,i) {
		// 	var sum=0;
		// 	for(var j=0;j<i;j++) {
		// 		sum+=b.w*text[j].name.length+b.s
		// 	}
		// 	return sum

		// }

		//Sequence SunBurst starts here 
		//createSunBurst('./app/mosaicattribute/allConvertedLoanPaths.csv');

		//draw the sunburst chart
		function createSunburst(url){
			//Dimensions of sunburst.

			var width=parseInt(d3.select('#sun').style('width'),10) - margin.left -margin.right;
			var height=width;
			var radius=Math.min(width,height) / 2;

//Breadcrumb dimensions: width, height, spacing, width of tip/tail\
			var b= {
				w: 75, h:30, s:3, t:10
			};
			var colors = {
				"Brand": "#5687d1",
				"wbm": "#7b615c",
				"other_site": "#de783b",
				"ag1":"#6ab975",
				"display" : "#a173d1",
				"SEO":"#bbbbbb",
				"agk":"#2ecc71",
				"Display":"#eeac99",
				"DM": "#3498db",
				"dmp": "#44a5e5",
			};

//Total size of all segments; we set this later, after loading the data.
			var totalSize=0;

			var vis=d3.select("#sunburst").append("svg:svg")
			.attr('width',width)
		  	.attr('height',height)
		  	.append('svg:g')
		  	.attr('id','container')
		  	.attr('transform',"translate("+width/2+","+height/2+")");
		  	var partition = d3.layout.partition()
		  	.size([2 * Math.PI, radius*radius])
		  	.value(function(d){ return d.size; });

		  	var arc=d3.svg.arc()
		  	.startAngle(function(d) {return d.x ; })
			.endAngle(function(d) {return d.x+d.dx ; })
			.innerRadius(function(d) {return Math.sqrt(d.y); })
			.outerRadius(function(d) {return Math.sqrt(d.y+d.dy); });

			//Use d3.text and d3.csv.parseRows so that we do not need to have a header
			//row, and can receive the csv as an array of arrays.
			d3.text(url, function(text) {
				var csv=d3.csv.parseRows(text);
				var result=filterByDate(csv, date)
				var json=buildHierarchy(result);
				creativeVisualization(json);
			});
			var date=[new Date('02/03/2017'), new Date('02/04/2017')];
			function filterByDate(cvs, date) {
				var result=[]
				cvs.forEach(function(d){
					var sdate=new Date(d[1])
					if(sdate<=date[1]&&sdate>=date[0]) {
						d[2]=parseInt(d[2])
						result.push(d)

					}
				});

				for(var i=0;i<result.length;i++) {
				for(var j=i+1;j<result.length;j++) {
				if(result[i][0]===result[j][0]){
					result[i][2]=result[i][2]+result[j][2];
					result.splice(j,1)
					j--;
				}
			}
		}
		return result
	}	
//Main function to draw and set up the visualization, once we have the data.
		function createVisualization(json) {

			//Basic setup of page elements.
			initializeBreadcrumbTrail();
			//drawLegend();
			//d3.select('#togglelegend').on("click",toggleLegend);

			//Bounding circle underneath the sunburst, to make it easier to detect
			//when the mouse leaves the parent g.
			vis.append("svg:circle")
				.attr("r", radius)
				.style("opacity",0);
			//For efficiency, filter nodes to keep only those large enough to see.
			var nodes=partition.nodes(json)
				.filter(function(d) {
					return (d.dx>0.005); //0.005 radians = 0.29 degrees
				});

			var path = vis.data([json]).selectAll("path.sun")
				.data(nodes)
				.enter().append("svg:path")
				.attr("display",function(d) { return d.depth ? null : "none"; })
				.attr("d",arc)
				.attr("fill-rule","evenodd")
				.style("fill", function(d){ return colors[d.name]; })
				.style("opacity", 1)
				.on("mouseover",mouseover);

				//Add the mouseleave handler to the building circle.
			d3.select("#container").on("mouseleave",mouseleave)

			//Get total soze of the tree=value of root node from partition.
			totalSize=path.node().__dATA__.value;
		};

		//fADE ALL THE CURRENT SEQUENCE, AND SHOW IT IN THE BREADCRUMB TRAIL.
		function mouseover(d) {

			var percentage=(100*d.value/totalSize).toPrecision(3);
			var percentageString=percentage+"%";
			if (percentage < 0.1) {
				percentageString = "<0.1%";
			}

			d3.select("#percentage")
					.text(percentageString);

			d3.select("#explanation")
					.style("visibility","");

			var sequenceArray = getAncestors(d);
			updateBreadcrumbs(sequenceArray, percentageString);

			//Fade all the segments.
			d3.selectAll("path.sun")
				.style("opacity",0.3);

				//Then highlight only those that are an ancestor of the current segment.
			vis.selectAll("path.sun")
				.filter(function(node) {
					return (sequenceArray.indexOf(node)>= 0);
				})
				.style("opacity",1);
		}

		//Rstore everything to full opacity when moving off the visualization
		function mouseleave(d) {

			//Hide the breadcrumb trail
			d3.select("#trail")
					.style("visibility","hidden");

			//Deactivate all segments during transition
			d3.selectAll("path.sun").on("mouseover", null);

			//transition each segment to full opacity and then reactivate it.
			d3.selectAll("path.sun")
				.transition()
				.duration(1000)
				.style("opacity",1)
				.each("end", function(){
					d3.select(this).on("mouseover",mouseover);
				});

				d3.select("#explanation")
				   .style("visibility","hidden");
		}

		//Given a node in a partition layout, return an array of all of its ancestor
//nodes, highest first, but excluding the root.
		function getAncestors(node) {
			var path = [];
			var current = node;
			while (current.parent) {
				path.unshift(current);
				current = current.parent;
			}
			return path;
		}

		function initializeBreadcrumbTrail() {
			// Add the svg area.
			var trail=d3.select('#sequence').append("svg:svg")
				.attr("width",width)
				.attr("height",50)
				.attr("id","trail");
				//add the label at the end, for the percentage
				trail.append("svg:text")
					.attr("id","endlabel")
					.style("fill","#000");
		}

		//Generate a string that describes the points of a breadcrumb polygon.
		function breadcrumbPoints(d,i){
			var points = [];
			points.push("0,0");
			points.push(b.w+",0");
			points.push(b.w+b.t+","+(b.h/2);
			points.push(b.w+","+b.h);
			points.push("0,"+b.h);
			if (i>0) {//Leftmost breadcrumb; don't include 6th vertex.
					points.push(b.t+","+(b.h/2));
		}
		return points.join("");
	}

//Update the breadcrumb trail to show the current sequence percentage.
		function updateBreadcrumbs(nodeArray, percentageString) {

			//Data join; key function combines name and depth (=position in sequence)
			var g=d3.select('#trail')
				.selectAll("g")
				.data(nodeArray, function(d){ return d.name + d.depth; });

				//Add breadcrumb and lable for entering nodes.
				var entering=g.enter().append("svg:g");

				entering.append("svg:polygon")
						.attr("points",breadcrumbPoints)
						.style("fill", function(d) { return colors[d.name]; });

				entering.append("svg:text")
						.attr("x", (b.w + b.t) / 2)
						.attr("y", b.h / 2)
						.attr("dy", "0.35em")
						.attr("text-anchor","middle")
						.text(function(d) { return d.name; });

						//Set the position for entering and updating nodes.
				g.attr("transform", function (d, i) {
					return "translate(" + i * (b.w + b.s) + ",0)";
				});

				//Remove exiting nodes.
				g.exit().remove();

				//Now move and update the percentage at the end.
				d3.select('#trail').select('#endlabel')
					.attr("x", (nodeArray.length  + 0.5) * (b.w +b.s))
					.attr("y", b.h/2)
					.attr("dy", "0.35em")
					.attr("text-anchor", "middle")
					.text(percentageString);

				//Make the breadcrumb trail visible, if it's hidden.
				d3.select('#trail')
					.style("visibility", "");

				}

				function drawLegend() {

					//Dimensions of legend item: width, height, spacing, radius of rounded rect.
					var li= {
						w:75, h:30, s:3, r:3
					};

					var legend=d3.select("#legend").append("svg:svg")
						.attr("width", li.w)
						.attr("height", d3.keys(colors).length * (li.h + li.s));

					var g=legend.selectAll("g")
						.data(d3.entries(colors))
						.enter().append("svg:g")
						.attr("transform", function(d,i) { 
							return "translate(0," +i*(li.h + li.s) +")";
				});

					g.append("svg:rect")
						.attr("rx",li.r)
						.attr("ry", li.r)
						.attr("width",li.w)
						.attr("height",li.h)
						.style("fill", function(d) { return d.value; });

					g.append("svg:text")
					 .attr("x", li.w / 2)
					 .attr("y", li.h / 2)
					 .attr("dy", "0.35em")
					 .attr("text-anchor","middle")
					 .text(function(d) { return d.key; });
				}

				function toggleLegend() {
					var legend = d3.select('#legend');
					if (legend.style("visibility") == "hidden") {
						legend.style("visibility","");
				} else {
					legend.style("visibility", "hidden");
				}
			}


			//Take a 2-column CSV and transform it into a hierarchical structure and suitable
			//for a partition layout. The first column is a sequence of step names, from
			//root to leaf, separated by hyphens. The second column is a count of how
			//often that sequence occurrec.
			function buildHierarchy(csv) {
				var root = {'name':"root", "children":[]};
				for(var i=0; i<csv.length; i++) {
					var sequence = csv[i][0];
					var size = +csv[i][2];
					if (isNan(size)) {//e.g. if this is a header row
						continue;
				}

				var parts = sequence.split(">");
				var currentNode = root;
				for (var j = 0; j < parts.length; j++) {
					//if the current Node doesn't have child, create one;
				var children = currentNode["children"]||[];
				var nodeName=parts[j];
				var childNode;
				if (j+1 < parts.length) {
					//Not yet at the end of the sequence; move down the tree.
					var foundChild=false;
					for(var k=0; k<children.length;k++){
						if (children[k]["name"] == nodeName) {
							childNode=children[k];
							foundChild=true;
							break;
						}
					}
					//If we dont already have a child for this breanch, create it.
					if(!foundChild) {
						childNode={"name":nodeName,"children":[]};
						children.push(childNode);
					}
					currentNode=childNode;
				} else {
					//Reached the end of the sequence; create a leaf node.
					childNode={"name":nodeName, "size":size};
					children.push(childNode);
				}
			}
		}
		return root;
	};
}
}]