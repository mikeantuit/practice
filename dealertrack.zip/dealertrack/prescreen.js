 function sum() {
     var char, x="",
        charCount = {},
         newStr = [],
         keyStr = [],
         palindrome = [],
         valueNum = [];
     var str = document.getElementsByClassName("prescreen-input")[0].value;
     var inarr = str.split("\n");
     inarr.forEach(function(item, index) {
         var i = item.indexOf(":"),
             key = item.slice(0, i),
             value = item.slice(i + 1);
        if(isNaN(value)){
            alert("The value must be a number");
        }
         keyStr.push(key);
         valueNum.push(value);
     });
     for (var i = 0; i < keyStr.length; i++) {
         char = keyStr[i];
         if (charCount[char]) {
             charCount[char] += parseInt(valueNum[i]);
         } else {
             charCount[char] = parseInt(valueNum[i]);
         }
         if (isPalindrome(char)) {
             palindrome.push(char);
         }
     }
     var keyarr = Object.getOwnPropertyNames(charCount);
     for (var j = 0; j < keyarr.length; j++) {
         x += "The total for " + keyarr[j] + " is " + charCount[keyarr[j]] + ".";
     }
     document.getElementsByClassName("presreen-output")[0].innerHTML = x;
     if(palindrome.length===0){
         document.getElementsByClassName("presreen-palindrome")[0].innerHTML = "No Palindrome Word.";
        }
         else{document.getElementsByClassName("presreen-palindrome")[0].innerHTML = "The Palindrome Word is " + palindrome.unique()+".";
        }
 }

 function isPalindrome(str) {
     var i, len = str.length;
     for (i = 0; i < len / 2; i++) {
         if (str[i] !== str[len - 1 - i])
             return false;
     }
     return true;
 }
 Array.prototype.unique = function() {
     this.sort();
     var re = [this[0]];
     for (var i = 1; i < this.length; i++) {
         if (this[i] !== re[re.length - 1]) {
             re.push(this[i]);
         }
     }
     return re;
 };
